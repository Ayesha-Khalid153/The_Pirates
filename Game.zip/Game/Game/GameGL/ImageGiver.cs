﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Game.Properties;

namespace Game.GameGL
{
    internal class ImageGiver
    {
        public static GameObject getBlankGameObject()
        {
            return new GameObject(GameObjectType.NONE, Resources.simplebox);
        }

        public static Image getPlayerImage()
        {
            return Resources.man;
        }

        public static Image getVerticalPoliceImage()
        {
            return Resources.police__1_;
        }

        public static Image getHorizontalPoliceImage()
        {
            return Resources.shooting_stick_man;
        }

        public static Image getRandomPoliceImage()
        {
            return Resources.police;
        }

        public static Image getPlayerBulletImage()
        {
            return Resources.playerBullet;
        }

        public static Image getHorizontalPoliceBulletImage()
        {
            return Resources.enemyBullet1;
        }

        public static Image getRandomPoliceBulletImage()
        {
            return Resources.randomEnemyBullet;
        }
        public static Image getVerticalPoliceBulletImage()
        {
            return Resources.verticalEnemyBullet;
        }
        public static GameObject GiveHeart()
        {
            return new GameObject(GameObjectType.HEART, Resources.money);
        }


        public static Image getGameObjectImage(char displayCharacter)
        {
            Image result = Resources.simplebox;

            if (displayCharacter == '#')
            {
                result = Resources.horizontal;
            }

            if (displayCharacter == '*')
            {
                result = Resources.money;
            }

            return result;
        }
    }
}
