﻿namespace Game
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.GameLoop = new System.Windows.Forms.Timer(this.components);
            this.bulletLoop = new System.Windows.Forms.Timer(this.components);
            this.lblThomasScoreNumber = new System.Windows.Forms.Label();
            this.lblThomasScore = new System.Windows.Forms.Label();
            this.lblThomasHealth = new System.Windows.Forms.Label();
            this.lblThomasHealthNumber = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // GameLoop
            // 
            this.GameLoop.Enabled = true;
            this.GameLoop.Tick += new System.EventHandler(this.gameLoop_Tick);
            // 
            // bulletLoop
            // 
            this.bulletLoop.Enabled = true;
            this.bulletLoop.Tick += new System.EventHandler(this.bulletLoop_Tick);
            // 
            // lblThomasScoreNumber
            // 
            this.lblThomasScoreNumber.AutoSize = true;
            this.lblThomasScoreNumber.BackColor = System.Drawing.Color.OrangeRed;
            this.lblThomasScoreNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThomasScoreNumber.ForeColor = System.Drawing.Color.Black;
            this.lblThomasScoreNumber.Location = new System.Drawing.Point(208, 356);
            this.lblThomasScoreNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThomasScoreNumber.Name = "lblThomasScoreNumber";
            this.lblThomasScoreNumber.Size = new System.Drawing.Size(33, 36);
            this.lblThomasScoreNumber.TabIndex = 0;
            this.lblThomasScoreNumber.Text = "0";
            // 
            // lblThomasScore
            // 
            this.lblThomasScore.AutoSize = true;
            this.lblThomasScore.BackColor = System.Drawing.Color.Transparent;
            this.lblThomasScore.Font = new System.Drawing.Font("Algerian", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThomasScore.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.lblThomasScore.ImageAlign = System.Drawing.ContentAlignment.TopLeft;
            this.lblThomasScore.Location = new System.Drawing.Point(63, 356);
            this.lblThomasScore.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThomasScore.Name = "lblThomasScore";
            this.lblThomasScore.Size = new System.Drawing.Size(138, 34);
            this.lblThomasScore.TabIndex = 1;
            this.lblThomasScore.Text = "Score : ";
            // 
            // lblThomasHealth
            // 
            this.lblThomasHealth.AutoSize = true;
            this.lblThomasHealth.BackColor = System.Drawing.Color.Transparent;
            this.lblThomasHealth.Font = new System.Drawing.Font("Algerian", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThomasHealth.ForeColor = System.Drawing.Color.Black;
            this.lblThomasHealth.Location = new System.Drawing.Point(290, 356);
            this.lblThomasHealth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThomasHealth.Name = "lblThomasHealth";
            this.lblThomasHealth.Size = new System.Drawing.Size(161, 34);
            this.lblThomasHealth.TabIndex = 3;
            this.lblThomasHealth.Text = "Health : ";
            // 
            // lblThomasHealthNumber
            // 
            this.lblThomasHealthNumber.AutoSize = true;
            this.lblThomasHealthNumber.BackColor = System.Drawing.Color.OrangeRed;
            this.lblThomasHealthNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThomasHealthNumber.ForeColor = System.Drawing.Color.Black;
            this.lblThomasHealthNumber.Location = new System.Drawing.Point(474, 354);
            this.lblThomasHealthNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblThomasHealthNumber.Name = "lblThomasHealthNumber";
            this.lblThomasHealthNumber.Size = new System.Drawing.Size(51, 36);
            this.lblThomasHealthNumber.TabIndex = 2;
            this.lblThomasHealthNumber.Text = "10";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1108, 557);
            this.Controls.Add(this.lblThomasHealth);
            this.Controls.Add(this.lblThomasHealthNumber);
            this.Controls.Add(this.lblThomasScore);
            this.Controls.Add(this.lblThomasScoreNumber);
            this.DoubleBuffered = true;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.Form1_Load);
            this.KeyDown += new System.Windows.Forms.KeyEventHandler(this.Form1_KeyDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Timer GameLoop;
        private System.Windows.Forms.Timer bulletLoop;
        private System.Windows.Forms.Label lblThomasScoreNumber;
        private System.Windows.Forms.Label lblThomasScore;
        private System.Windows.Forms.Label lblThomasHealth;
        private System.Windows.Forms.Label lblThomasHealthNumber;
    }
}

